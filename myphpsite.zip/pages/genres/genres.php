<?php include "../../includes/config.php" ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Жанры</title>

  <!-- Bootstrap Grid -->
  <link rel="stylesheet" type="text/css" href="/media/assets/bootstrap-grid-only/css/grid12.css">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">

  <!-- Custom -->
  <link rel="stylesheet" type="text/css" href="/media/css/style.css">
</head>
<body>

  <div id="wrapper">

    <header id="header">
        <div class="header__top">
        <div class="container">
          <div class="header__top__logo">
            <h1>Жанры</h1>
          </div>
        </div>
      </div>

      <?php include "../../includes/bottom_header.php" ?>
    </header>

        <?php $genre = mysqli_query($connection, "SELECT * FROM `genres`") ?>

    <div id="content">
      <div class="container">
        <div class="row">
          <section class="content__left col-md-8">
            <div class="block">
              <a href="/pages/all_books/all_books.php">Все книги</a>
              <h3>Жанры</h3>
              <div class="block__content">

                  <?php 

                    while ($book = mysqli_fetch_assoc($genre)) 

                    {
                      ?>

                        <li><a href="books_by_genre.php?genre_id=<?php echo $book['genre_id'] ?>"><?php echo $book['genre']; ?></a><br><br></li>

                      <?php

                    }

                   ?>

              </div>
            </div>

          </section>
          <section class="content__right col-md-4">

            <?php include "../../includes/sidebar.php" ?>
            
          </section>
        </div>
      </div>
    </div>

    <footer id="footer">
      <div class="container">
        <div class="footer__logo">
          <h1>Жанры</h1>
        </div>
      </div>
    </footer>

  </div>

</body>
</html>