<?php

include "../../includes/config.php";

$book_name = $_GET['book_name'];

/* получатели */
$to = $_GET['recipient_email']  . ", " ; //обратите внимание на запятую
$to .= $config['admin_email'];

/* тема/subject */
$subject = "Ваш заказ оформлен";

/* сообщение */
$message = '
<html>
<head>
 <title>Благодарим за ваш заказ!</title>
</head>
<body>
<p>Информация о заказе</p>
Вы заказали книгу: 
</body>
</html>
';

/* Для отправки HTML-почты вы можете установить шапку Content-type. */
$headers= "MIME-Version: 1.0\r\n";
$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";

/* дополнительные шапки */
$headers .= "From: Birthday Reminder <admin@booksforall.com>\r\n";

/* и теперь отправим из */
mail($to, $subject, $message, $headers);

echo "Благодарим за заказ! Детали отправлены вам на почту.";

?>