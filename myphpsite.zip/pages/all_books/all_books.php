<?php include "../../includes/config.php" ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Все книги</title>

  <!-- Bootstrap Grid -->
  <link rel="stylesheet" type="text/css" href="/media/assets/bootstrap-grid-only/css/grid12.css">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">

  <!-- Custom -->
  <link rel="stylesheet" type="text/css" href="/media/css/style.css">
</head>
<body>

  <div id="wrapper">

    <header id="header">
        <div class="header__top">
        <div class="container">
          <div class="header__top__logo">
            <h1>Все книги</h1>
          </div>
        </div>
      </div>

      <?php include "../../includes/bottom_header.php" ?>
    </header>

        <?php $all_books = mysqli_query($connection, "SELECT * FROM `books_data`"); ?>

    <div id="content">
      <div class="container">
        <div class="row">
          <section class="content__left col-md-8">
            <div class="block">
              <a href="/pages/all_books/all_books.php">Все книги</a>
              <div class="block__content">
                <div class="articles articles__horizontal">

                	<?php 

                		while ($cat = mysqli_fetch_assoc($all_books)) 

                		{

                			?>

				              <article class="article">
				                <div class="article__image" style="background-image: url(/media/images/test.jpg);"></div>
				                <div class="article__info">
				                  <a href="../book/book.php?id=<?php echo $cat['id'] ?>"><?php echo $cat['name']; ?></a>
                          <hr>
				                  <div class="article__info__preview"><?php echo mb_substr($cat['description'], 0, 100, 'utf8') . "..."; ?></div>
				                </div>
				              </article>
                		
                			<?php

                		}

                	 ?>

                </div>
              </div>
            </div>

          </section>
          <section class="content__right col-md-4">

          	<?php include "../../includes/sidebar.php" ?>

          </section>
        </div>
      </div>
    </div>

    <footer id="footer">
      <div class="container">
        <div class="footer__logo">
          <h1>Все книги</h1>
        </div>
      </div>
    </footer>

  </div>

</body>
</html>