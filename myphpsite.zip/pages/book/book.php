<?php 
  require "../../includes/config.php"
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?php echo $config['title']; ?></title>

  <!-- Bootstrap Grid -->
  <link rel="stylesheet" type="text/css" href="/media/assets/bootstrap-grid-only/css/grid12.css">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">

  <!-- Custom -->
  <link rel="stylesheet" type="text/css" href="../../media/css/style.css">
</head>
<body>

  <div id="wrapper">

    <header id="header">
        <div class="header__top">
        <div class="container">
          <div class="header__top__logo">
            <h1><?php echo $config['title']; ?></h1>
          </div>
        </div>
      </div>

      <?php include "../../includes/bottom_header.php" ?>
    </header>

              <?php 

              $book_id = $_GET['id'];

              $authors = mysqli_query($connection, 
              "SELECT books_data.name, books_data.description, GROUP_CONCAT(genres.genre SEPARATOR ', ') 
              FROM books_data 
              INNER JOIN books_genres 
              ON books_data.id = books_genres.book_id
              LEFT JOIN genres 
              ON books_genres.genre_id = genres.genre_id
              WHERE books_data.id = $book_id
              GROUP BY books_data.name"); 
                    
              $cat = mysqli_fetch_assoc($authors);
              ?>

    <div id="content">
      <div class="container">
        <div class="row">
          <section class="content__left col-md-8">
            <div class="block">
              <h2><?php echo $cat['name']; ?></h2>
              <div class="block__content">
                <div class="block__image"><img src="../../media/images/test.jpg"></div>

                <div class="full-text">
<h3>Жанры: <?php echo $cat["GROUP_CONCAT(genres.genre SEPARATOR ', ')"]; ?></h3>

<p>Описание:</p>

<p><?php echo $cat['description'] ?></p>

                </div>
              </div>
            </div>

          </section>
          <section class="content__right col-md-4">
            <?php include "../../includes/sidebar.php" ?>
          </section>
        </div>
      </div>
    </div>

    <footer id="footer">
      <div class="container">
        <div class="footer__logo">
          <h1><?php echo $config['title']; ?></h1>
        </div>
      </div>
    </footer>

  </div>

</body>
</html>