          <?php $most_purchased_books = mysqli_query($connection, "SELECT * FROM `books_data` ORDER BY 'purchases' DESC LIMIT 3"); ?>

            <div class="block">
              <h3>Топ покупаемых книг</h3>
              <div class="block__content">
                <div class="articles articles__vertical">

                      <?php 

                    while ($book = mysqli_fetch_assoc($most_purchased_books)) 

                    {

                      ?>

                  <article class="article">
                    <div class="article__image" style="background-image: url(/media/images/test.jpg);";></div>
                    <div class="article__info">
                      <a href="../pages/book/book.php?id=<?php echo $book['id'] ?>"><?php echo $book['name']; ?></a>
                      <hr>
                      <div class="article__info__preview"><?php echo mb_substr($book['description'], 0, 100, 'utf8') . "..."; ?></div>
                    </div>
                  </article>
                    
                      <?php

                    }

                   ?>

                </div>
              </div>
            </div>