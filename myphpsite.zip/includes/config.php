<?php

$config = array('title' => 'Книги для всех',
				'db' => array(
						'server' => 'localhost',
						'username' => 'root',
						'password' => '',
						'name' => 'books'
						 ),
				'admin_email' => 'atymofiiv@geeksforless.net'
				 );

require 'db.php';