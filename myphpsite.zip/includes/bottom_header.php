<div class="header__bottom">
        <div class="container">
          <nav>
            <ul>
              <li><a href="/">Главная</a></li>
              <li><a href="/pages/genres/genres.php">Жанры</a></li>
              <li><a href="/pages/authors/authors.php">Авторы</a></li>
              <li><a href="/pages/order/order.php">Заказать книгу</a></li>
              <li><a href="../../admin/admin.php">Вход</a></li>

            </ul>
          </nav>
        </div>
      </div>